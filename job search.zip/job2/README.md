由于user 表重新增加jobid的Array，需要重新注册user再进行favorite list 的添加

